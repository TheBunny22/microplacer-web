const express = require("express");
const {
  createPayment,
  getStatusController,
} = require("../controllers/paymentController");

const paymentRoutes = express.Router();

paymentRoutes.get("/pay", (req, res) => {
  const { oid } = req.query;
  const html = `<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Pay Now - Loading Screen</title>
      <link rel="stylesheet" href="styles.css" />
      <style>
        body {
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          background-color: #f1f1f1;
        }
  
        .loader-container {
          display: flex;
          flex-direction: column;
          align-items: center;
        }
  
        .loader {
          border: 8px solid #f3f3f3;
          border-top: 8px solid #3498db;
          border-radius: 50%;
          width: 60px;
          height: 60px;
          animation: spin 1.5s linear infinite;
        }
  
        .loader-text {
          margin-top: 20px;
          font-size: 18px;
          color: #555;
        }
  
        @keyframes spin {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
      </style>
    </head>
    <body>
      <div class="loader-container">
        <div class="loader"></div>
        <p class="loader-text">Initializing payment Gateway ...</p>
      </div>
      <script>
        window.addEventListener("DOMContentLoaded", async function () {
          const response = await fetch(
            "https://microplacer.in/apies/payment/create?oid=${oid}"
          );
          const data = await response.json();
          const url = data.redirect.data.instrumentResponse.redirectInfo.url;
          window.location.href = url;
        });
      </script>
    </body>
  </html>
  `;
  res.send(html);
});
paymentRoutes.get("/create", createPayment);
paymentRoutes.get("/status/:transactionID", getStatusController);

module.exports = paymentRoutes;
