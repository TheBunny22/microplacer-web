const express = require("express");
const authenticateUser = require("../middlewares/authenticateUser");
const userController = require("../controllers/userController");
const fileUpload = require("express-fileupload");
const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");

const userRoutes = express.Router();
userRoutes.use(fileUpload());

userRoutes.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
  next();
});

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "donotreply@microplacer.com",
    pass: "Deep_HD_1994",
  },
});

// POST routes
userRoutes.post("/register", userController.registerUser);
userRoutes.post("/login", userController.loginUser);
userRoutes.post("/verify-otp", userController.verifyOtp);
userRoutes.post("/change-password", authenticateUser, userController.changePassword);
userRoutes.post("/insertCart", authenticateUser, userController.addCartItem);
userRoutes.post("/addcart-item", authenticateUser, userController.addCartItem);
userRoutes.post("/getprice", userController.fetchPrice);
userRoutes.post("/select-cart-item", authenticateUser, userController.selectCartItem);
userRoutes.post("/select-all-cart-item", authenticateUser, userController.selectAllCartItems);
userRoutes.post("/update-contact", authenticateUser, userController.insertAddresss);
userRoutes.post("/resend-otp", userController.resendOtp);
userRoutes.post("/updateProfile", userController.resetMail);
userRoutes.post("/update/verify", userController.UpdateProfile);

// GET routes
userRoutes.get("/sendOTP", authenticateUser, userController.sendMailOtp);
userRoutes.get("/cart", authenticateUser, userController.getCart);
userRoutes.get("/myorders", authenticateUser, userController.getOrders);
userRoutes.get("/getuserdetail", authenticateUser, userController.getusersData);

// DELETE route
userRoutes.delete("/remove-cart-item/:cartItemId", authenticateUser, userController.removeCartItem);

// File upload
userRoutes.delete("/empty-cart", authenticateUser, userController.emptyCart);

// Route to upload the file
userRoutes.post("/orderfile", userController.uploadOrderFile);

// Order placing routes
userRoutes.post("/place-order", authenticateUser, userController.placeOrder);

// Gerber viewers routes
userRoutes.post("/get-file-path", userController.getFilePath);
userRoutes.get("/download-file", userController.downloadFile);
userRoutes.post("/upload-gerber-svg", userController.UploadGerberView);
userRoutes.post("/get-gerber-svg", userController.getGerberView);

// Contact us API
userRoutes.post("/contact", userController.sendQueryMail);

// Stencil inquiry API
userRoutes.post("/stencil-inquiry", async (req, res) => {
  try {
    const { file } = req.files;
    const { data } = req.body;

    const dat = JSON.parse(data);
    let subject;

    if (dat.size) {
      subject = "PCB Stencil Inquiry";
    } else if (dat.layer) {
      subject = "PCB Design Inquiry";
    } else {
      subject = "BOM Inquiry";
    }

    const mailOptions = {
      from: "donotreply@microplacer.com",
      to: "micro@microplacer.com",
      subject: `${subject}`,
      html: `
        <!DOCTYPE html>
        <html>
          <head>
            <style>
              /* Add your custom CSS styles here */
              body {
                font-family: Arial, sans-serif;
                background-color: #f1f1f1;
              }

              .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 10px;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
              }

              .header {
                text-align: center;
                margin-bottom: 20px;
              }

              .info {
                margin-bottom: 20px;
              }

              .info p {
                margin: 0;
                line-height: 1.5;
              }

              .info strong {
                font-weight: bold;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h2>${subject}</h2>
              </div>
              <div class="info">
                ${Object.entries(dat)
                  .map(
                    ([key, value]) => `
                      <p key="${key}">
                        <strong>${key}: </strong>${value}
                      </p>
                    `
                  )
                  .join("")}
              </div>
            </div>
          </body>
        </html>
      `,
      attachments: [],
    };

    if (file) {
      const filePath = path.join(__dirname, file.name);
      fs.writeFileSync(filePath, file.data, "binary");

      mailOptions.attachments.push({
        filename: file.name,
        path: filePath,
        contentType: "application/zip",
      });
    }

    await transporter.sendMail(mailOptions);

    // Delete the temporary file after sending the email
    if (file) {
      const filePath = path.join(__dirname, file.name);
      fs.unlinkSync(filePath);
    }

    console.log("Mail sent successfully");
    return res.sendStatus(200);
  } catch (error) {
    console.log(error);
    return res.status(500).json("Failed to send the stencil inquiry.");
  }
});


userRoutes.post("/pay",(req,res)=>{
    console.log(req.body)
    res.status(200).json({msg:"done"})
})


module.exports = userRoutes;
