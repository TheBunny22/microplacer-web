const express = require("express");
const {
  AdminLogin,
  downloadGerberFile,
  updateOrderType,
  approveAllNewOrder,
  getAllApprovedOrders,
  getOrders,
  getClients,
  getPricingDetail,
  updateSpecsdetails,
  updateAreaDetails,
  sendPayoutLink,
  updateOrderStatus,
  updateOrderbyId,
  updatePaidStatus,
  changeAmount,
  dispatchOrder,
} = require("../controllers/adminController");
const adminAuth = require("../middlewares/authenticateAdmin");

const adminRoutes = express.Router();
adminRoutes.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
  next();
});

//admin login
adminRoutes.post("/login", AdminLogin);
//post
adminRoutes.post("/update-order-type", adminAuth, updateOrderType);
adminRoutes.post("/send-payment-link", adminAuth, sendPayoutLink);
adminRoutes.post("/update-order-status", adminAuth, updateOrderStatus);
adminRoutes.post("/update-order", adminAuth, updateOrderbyId);
adminRoutes.post("/update-paid", adminAuth, updatePaidStatus);
adminRoutes.post("/update-amount", adminAuth, changeAmount);
adminRoutes.post("/dispatch", adminAuth, dispatchOrder);
//get
adminRoutes.get("/get-order", adminAuth, getOrders);
adminRoutes.get("/approve-all-new", adminAuth, approveAllNewOrder);
adminRoutes.get("/approved-orders", adminAuth, getAllApprovedOrders);
adminRoutes.get("/getclient", adminAuth, getClients);
adminRoutes.get("/getPricingDetail", adminAuth, getPricingDetail);
// download gerber
adminRoutes.get("/download-gerber/:filePath", adminAuth, downloadGerberFile);
//price changing routes
adminRoutes.post("/specs-update", adminAuth, updateSpecsdetails);
adminRoutes.post("/area-update", adminAuth, updateAreaDetails);

module.exports = adminRoutes;
