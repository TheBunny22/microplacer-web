const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();
const validator = require("validator");
const Admin = require("../models/adminModel");
const Order = require("../models/orderModel");
const path = require("path");
const User = require("../models/userModel");
const PCBPriceModel = require("../models/pcbPricingModel");
const Pricing = require("../models/pricingModel");
const nodemailer = require("nodemailer");
const secret = process.env.SECRET;

const createToken = (_id) => {
  return jwt.sign({ _id }, secret, { expiresIn: "1h" });
};

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true, // use SSL
  auth: {
    user: "donotreply@microplacer.com",
    pass: "Deep_HD_1994",
  },
});

const AdminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    const validEmail = validator.isEmail(email);
    if (!validEmail) {
      return res.status(409).json({ msg: "email not valid" });
    }

    if (!email || !password) {
      return res.status(409).json({ msg: "All fields must be filled" });
    }

    const admin = await Admin.login(email, password);

    if (!admin) {
      return res.status(409).json({ msg: "All fields must be filled" });
    }
    const token = createToken(admin._id);

    res.status(200).json({ msg: `Welcome ${email}`, token });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getOrders = async (req, res) => {
  try {
    const type = req.query.type;
    const orders = await Order.getAllOrders(type);
    if (!orders) {
      return res.status(404).json({ msg: `no orders found ` });
    }
    return res.status(200).json({ orders });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const getAllApprovedOrders = async (req, res) => {
  try {
    const orders = await Order.getAllApprovedOrders();
    if (!orders) {
      return res.status(404).json({ msg: `no orders found ` });
    }

    return res.status(200).json({ orders });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const downloadGerberFile = async (req, res) => {
  const filePath = req.params.filePath;
  const fileName = path.basename(filePath);
  res.download(filePath, fileName, (err) => {
    if (err) {
      console.error("Error while downloading file:", err);
      res.status(404).send("File not found");
    }
  });
};

const updateOrderType = async (req, res) => {
  const covertDate = (timeStamp) => {
    const date = new Date(timeStamp);
    try {
      const time = date.getDate();
      const time1 = date.getMonth();
      const time2 = date.getFullYear();
      const time3 = date.getHours();
      const time4 = date.getMinutes();
      const time5 = date.getSeconds();
      return `${time}/${time1}/${time2} at ${time3}:${time4}:${time5}`;
    } catch (error) {
      return timeStamp;
    }
  };
  const { _oid, type } = req.body;
  console.log(req.body);

  try {
    const updated = await Order.updateOrdertype(_oid, type);

    if (!updated) {
      return res.status(203).json({ msg: `No order updated`, updated });
    }

    const order = await Order.findOne({ _oid }).exec();
    if (!order) {
      return res.status(404).json({ mssg: "Order not found" });
    }

    const user = await User.findOne({ _id: order.customerId }).exec();
    if (!user) {
      return res.status(404).json({ mssg: "User not found" });
    }

    if (type === "approved") {
      const paymentLink = `https://microplacer.in/apies/payment/pay?oid=${_oid}`;
      if (!_oid || !paymentLink) {
        return res.status(203).json({ mssg: `Provide all params` });
      }

      await Order.addPaymentLink(_oid, paymentLink);

      const email = user.email;
      const date = covertDate(order.createdAt);

      await transporter.sendMail({
        from: "donotreply@microplacer.com",
        to: email,
        subject: `Order Payment - Microplacer - ${_oid}`,
        html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Order Payment - Microplacer</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              background-color: #f2f2f2;
              padding: 20px;
            }

            .container {
              max-width: 600px;
              margin: 0 auto;
              background-color: #ffffff;
              padding: 20px;
              border-radius: 5px;
              box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }

            h1 {
              color: #333;
              margin-bottom: 20px;
            }

            p {
              margin-bottom: 10px;
              line-height: 1.5;
            }

            ul {
              margin-bottom: 10px;
              padding-left: 20px;
            }

            a {
                padding: 0.8rem 1rem;
                text-decoration:none;
                font-size: 17px;
                background-color: rgb(43, 140, 237);
                border: none;
                color: white;
                width: 20rem;
                border-radius: 0.5rem;
                font-weight: 500;
            }
           

            .signature {
              margin-top: 20px;
              font-style: italic;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Order Payment - Microplacer</h1>
            <p>Dear Customer,</p>
            <p>Thank you for choosing Microplacer for your PCB manufacturing needs. We are excited to start working on your order.</p>
            <p><strong>Order Details:</strong></p>
            <ul>
              <li>Order Number: ${_oid}</li>
              <li>Order Date:${date} </li>
              <li>Amount : ${order.amount} </li>
              <li>Quantity:${order.pcbs.quantity}</li>
            </ul>
            <p>To proceed with the order, we kindly request you to complete the payment. Please click on the payment link below:</p>
            <p><a href="${paymentLink}"  >Make Payment</a></p>
            <p>Please note that your order will only be processed after we receive the payment confirmation. If you have already made the payment, kindly disregard this message.</p>
            <p>If you have any questions or require further assistance, please feel free to contact our customer support team. We are here to help you.</p>
            <p>Thank you for choosing Microplacer. We look forward to serving you.</p>
            <p class="signature">Best regards,<br>Microplacer Team</p>
            <p><em>Contact Information:</em><br>
            Phone: +91 8866188126 / +91 9512012125 <br>
          </div>
        </body>
        </html>
        `,
      });

      return res.status(200).json({ mssg: `Payment link sent to: ${email}` });
    } else if (type === "rejected") {
      await transporter.sendMail({
        from: "donotreply@microplacer.com",
        to: user.email,
        subject: "Microplacer Order Rejected",
        html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Order Rejection - Microplacer</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.5;
              color: #333;
              margin: 0;
              padding: 20px;
            }
        
            .container {
              max-width: 600px;
              margin: 0 auto;
            }
        
            h1 {
              color: #333;
              margin-top: 0;
            }
        
            ul {
              padding-left: 20px;
            }
        
            p, ul {
              margin-bottom: 10px;
            }
        
            strong {
              font-weight: bold;
            }
        
            em {
              font-style: italic;
            }  a{
              display:block;   padding:1rem ; width : 10rem ; text-align: center ; background:#fff; color:#252525 ; text-decoration :none ;  border : 1px solid #ccc;border-radius : 2rem}
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Order Rejection - Microplacer</h1>
            <p>Dear Customer,</p>
            <p>We regret to inform you that your recent order with Microplacer for PCB manufacturing has been rejected.</p>
            <p><strong>Order Details:</strong></p>
            <ul>
              <li>Order Number: ${_oid}</li>
              <li>Order Date: ${new Date(updated.createdAt)}</li>
              <li>Quantity: ${updated.pcbs.quantity}</li>
            </ul>
            <p>Unfortunately, after careful consideration, we are unable to proceed with the manufacturing of your PCBs. Due to unforeseen circumstances, we are currently unable to fulfill the order within the requested timeframe.</p>
            <p>We understand the importance of timely delivery and apologize for any inconvenience caused. If you have already made a payment, we will initiate a full refund for the order amount within the next 3-5 business days.</p>
            <p>If you have any further questions or require assistance with alternative solutions, please do not hesitate to contact our customer support team. We will be happy to assist you in finding an alternative solution or provide recommendations for other reliable PCB manufacturing services.</p>
            <p>Once again, we apologize for any inconvenience caused and appreciate your understanding in this matter.</p>
            <p>Best regards,</p>
            <p>Microplacer Team</p>
            <p><em>Contact Information:</em><br>
            Phone: +91 8866188126 / +91 9512012125 <br>
            Email: info@microplacer.com</p>
          </div>
        </body>
        </html>
        `,
      });
    }

    return res.status(200).json({ msg: "Updated", updated });
  } catch (error) {
    console.log(error.message);
    return res
      .status(500)
      .json({ err: `Internal server error: ${error.message}` });
  }
};
const approveAllNewOrder = async (req, res) => {
  try {
    const approved = await Order.updateMany(
      { orderType: "new" },
      { $set: { orderType: "approved" } }
    );
    if (!approved) {
      return res.status(404).json({ msg: "no orders to update " });
    }
    return res.status(200).json({ msg: " all orders are approved", approved });
  } catch (error) {}
};

const getClients = async (req, res) => {
  try {
    const users = await User.getAllUser();
    if (!users) {
      return res.status(404).json({ msg: `No user found` });
    }
    return res.status(200).json(users);
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const getPricingDetail = async (req, res) => {
  try {
    const users = await PCBPriceModel.getAll();
    const area = await Pricing.getAll();
    if (!users || !area) {
      return res.status(404).json({ msg: `No user found` });
    }
    return res.status(200).json({ specs: users, area: area });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const updateSpecsdetails = async (req, res) => {
  try {
    const { specId, optionId, value } = req.body;
    if (!specId || !optionId || !value) {
      return res.status(203).json({ msg: "Provide full details" });
    }
    const updated = await PCBPriceModel.updateSpecOption(
      specId,
      optionId,
      value
    );
    if (!updated) {
      return res.status(404).json({ msg: "Not updated" });
    }
    return res.status(200).json({ specs: updated });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const updateAreaDetails = async (req, res) => {
  const { val, _id, valType } = req.body;
  try {
    const updated = await Pricing.updateSCM(val, _id, valType);
    if (!updated) {
      return res.status(404).json({ msg: "Not updated" });
    }
    return res.status(200).json({ specs: updated });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};
const covertDate = (timeStamp) => {
  const date = new Date(timeStamp);
  try {
    const time = date.getDate();
    const time1 = date.getMonth();
    const time2 = date.getFullYear();
    const time3 = date.getHours();
    const time4 = date.getMinutes();
    const time5 = date.getSeconds();
    return `${time}/${time1}/${time2} at ${time3}:${time4}:${time5}`;
  } catch (error) {
    return timeStamp;
  }
};
const sendPayoutLink = async (_oid) => {
  const paymentLink = `https://microplacer.in/apies/payment/pay?oid=${_oid}`;
  if (!_oid || !paymentLink) {
    return res.status(203).json({ mssg: `provide all params` });
  }

  try {
    const order = await Order.findOne({ _oid }).exec();

    if (!order) {
      return res.status(404).json({ mssg: "Order not found" });
    }
    console.log(order);
    const user = await User.findOne({ _id: order.customerId }).exec();

    if (!user) {
      return res.status(404).json({ mssg: "User not found" });
    }
    Order.addPaymentLink(_oid, paymentLink);
    const email = user.email;
    const date = covertDate(order.createdAt);
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: `Order Payment - Microplacer - ${_oid}`,
      html: ` <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Order Payment - Microplacer</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              background-color: #f2f2f2;
              padding: 20px;
            }

            .container {
              max-width: 600px;
              margin: 0 auto;
              background-color: #ffffff;
              padding: 20px;
              border-radius: 5px;
              box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }

            h1 {
              color: #333;
              margin-bottom: 20px;
            }

            p {
              margin-bottom: 10px;
              line-height: 1.5;
            }

            ul {
              margin-bottom: 10px;
              padding-left: 20px;
            }

            a{
              display:block;   padding:1rem ; width : 10rem ; text-align: center ; background:#fff; color:#252525 ; text-decoration :none ;  border : 1px solid #ccc;border-radius : 2rem}
           

            .signature {
              margin-top: 20px;
              font-style: italic;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Order Payment - Microplacer</h1>
            <p>Dear Customer,</p>
            <p>Thank you for choosing Microplacer for your PCB manufacturing needs. We are excited to start working on your order.</p>
            <p><strong>Order Details:</strong></p>
            <ul>
              <li>Order Number: ${_oid}</li>
              <li>Order Date:${date} </li>
              <li>Amount : ${order.amount}</li>
              <li><strong>Quantity:</strong>${order.pcbs.quantity}</li>
            </ul>
            <p>To proceed with the order, we kindly request you to complete the payment. Please click on the payment link below:</p>
            <p><a href="${paymentLink}"  >Make Payment</a></p>
            <p>Please note that your order will only be processed after we receive the payment confirmation. If you have already made the payment, kindly disregard this message.</p>
            <p>If you have any questions or require further assistance, please feel free to contact our customer support team. We are here to help you.</p>
            <p>Thank you for choosing Microplacer. We look forward to serving you.</p>
            <p class="signature">Best regards,<br>Microplacer Team</p>
            <p><em>Contact Information:</em><br>
            Phone: +91 8866188126 / +91 9512012125 <br>
          </div>
        </body>
        </html>

         `,
    });

    return res.status(200).json({ mssg: `Payment link sent to: ${email}` });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ err: err.message });
  }
};

// change status of pcbs updateOrderStatus
const updateOrderStatus = async (req, res) => {
  const { _oid, status } = req.body;
  try {
    const updated = await Order.updateOrderStatus(_oid, status);

    if (!updated) {
      return res.status(500).json({ msg: `No update occured` });
    }
    return res.status(200).json({ msg: `Updated Success`, order: updated });
  } catch (err) {
    return res.status(500).json({ err: err.message });
  }
};
// chnage orderspecs updateOrderById
const updateOrderbyId = async (req, res) => {
  const { _oid, order } = req.body;
  try {
    const updated = await Order.updateOrderById(_oid, order);

    const user = await User.findOne({ _id: order.customerId }).exec();
    if (!updated || !user) {
      return res.status(500).json({ msg: `No update occured` });
    }

    const email = user.email;

    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: `Order Modification - Microplacer - ${_oid}`,
      html: `
      <!DOCTYPE html>
<html>
<head>
  <title>Order Modification - Microplacer</title>
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      padding: 20px;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    h1 {
      color: #333333;
      font-size: 24px;
      margin: 0 0 20px 0;
    }
    h2 {
      color: #333333;
      font-size: 18px;
      margin: 0 0 10px 0;
    }
    p {
      color: #555555;
      font-size: 16px;
      margin: 0 0 10px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th {
      background-color: #f2f2f2;
      color: #333333;
      font-weight: bold;
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #e0e0e0;
    }
    td {
      padding: 10px;
      border-bottom: 1px solid #e0e0e0;
    } 
  </style>
</head>
<body>
  <div class="container">
    <h1>Order Modification - Microplacer</h1>
    <p>Dear Customer,</p>
    <p>We would like to inform you that there has been a modification to your order with Microplacer. Please find the updated details below:</p>
    <h2>Order Details</h2>
    <p><strong>Order ID:</strong> ${updated[0]._oid}</p>
    <p><strong>Company Name:</strong> ${updated[0].billingAddress.companyName}</p>
    <p><strong>Modified Amount:</strong> ₹${updated[0].pcbs.price}</p>
    <p><strong>Quantity:</strong>${updated[0].pcbs.quantity}</p>
    <h2>Modified Gerber Details</h2>
    <table>
       <tr>
                <th>Specification</th>
                <th>Value</th>
              </tr>
              <tr>
                <td>Base Material</td>
                <td>${updated[0].pcbs.baseMaterial}</td>
                </tr>
                <tr>
                <td>Layer</td>
                <td>${updated[0].pcbs.layer}</td>
              </tr>
              <tr>
                <td>Dimension X</td>
                <td>${updated[0].pcbs.dimensionX}</td>
              </tr>
              <tr>
                <td>Dimension Y</td>
                <td>${updated[0].pcbs.dimensionY}</td>
              </tr>
              <tr>
                <td>Thickness</td>
                <td>${updated[0].pcbs.thickness}</td>
              </tr>
              <tr>
                <td>Color</td>
                <td>${updated[0].pcbs.color}</td>
              </tr>
              <tr>
                <td>Surface Finish</td>
                <td>${updated[0].pcbs.surfaceFinish}</td>
              </tr>
              <tr>
                <td>Outer Copper Weight</td>
                <td>${updated[0].pcbs.outerCopperWeight}</td>
              </tr>
              <tr>
                <td>Gold Finger</td>
                <td>${updated[0].pcbs.goldFinger}</td>
              </tr>
              <tr>
                <td>Castellated Holes</td>
                <td>${updated[0].pcbs.castellatedHoles}</td>
              </tr>
              <tr>
                <td>Kelvin Test</td>
                <td>${updated[0].pcbs.kelvinTest}</td>
              </tr>
              <tr>
                <td>Delivery Format</td>
                <td>${updated[0].pcbs.deliveryFormat}</td>
              </tr>
              <tr >
                <td>Price</td>
                <td>₹${updated[0].pcbs.price}</td>
              </tr>
              <tr style="color:red">
                <td>Order Status</td>
                <td>${updated[0].pcbs.status}</td>
              </tr>
              <tr>
                <td>Remarks</td>
                <td>${updated[0].pcbs.remarks}</td>
              </tr>
    </table>
    <p>If you have any questions or concerns regarding this modification, please don't hesitate to contact our customer support.</p>
    <p>
    Microplacer Technologies LLP
    <br/>
    Phone: +91 8866188126 / +91 9512012125 
    <br/>
    Email: info@microplacer.com
    </p>
  </div>
</body>
</html>

      `,
    });

    return res.status(200).json({ msg: `Updated Success`, order: updated });
  } catch (err) {
    console.log;
    return res.status(500).json({ err: err.message });
  }
};

const updatePaidStatus = async (req, res) => {
  const { _oid, paid } = req.body;

  try {
    const updatedOrder = await Order.updatePaidStatus(_oid, paid);
    if (!updatedOrder) {
      return res.status(203).json({ msg: `no update occured` });
    }
    return res
      .status(200)
      .json({ msg: "Paid status updated successfully", order: updatedOrder });
  } catch (err) {
    return res.status(500).json({ err: err.message });
  }
};

const dispatchOrder = async (req, res) => {
  const { _oid, deliveryPartner, trackId } = req.body;
  try {
    const order = await Order.findOne({ _oid }).exec();

    if (!order) {
      return res.status(404).json({ mssg: "Order not found" });
    }

    const user = await User.findOne({ _id: order.customerId }).exec();

    const updatedOrder = await Order.insertDLP(_oid, deliveryPartner, trackId);
    if (!updatedOrder) {
      return res.status(203).json({ msg: `no update occured` });
    }
    const email = user.email;
    const updated = await Order.updateOrdertype(_oid, "dispatched");
    const date = covertDate(order.createdAt);
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: `Order Dispatched - Microplacer - ${_oid}`,
      html: `<!DOCTYPE html>
      <html>
      <head>
        <style>
          /* Reset default styles */
          body, p {
            margin: 0;
            padding: 0;
          }
      
          /* Container styles */
          .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #f4f4f4;
            padding: 20px;
            font-family: Arial, sans-serif;
          }
      
          /* Heading styles */
          h1 {
            color: #333333;
            font-size: 24px;
            margin-bottom: 20px;
          }
      
          /* Content styles */
          p {
            color: #555555;
            font-size: 16px;
            line-height: 1.5;
            margin-bottom: 10px;
          }
      
          /* Button styles */
          .button {
            display: inline-block;
            background-color: #007bff;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 20px;
          }
      
          .button:hover {
            background-color: #0056b3;
          }   a{
            display:block;   padding:1rem ; width : 10rem ; text-align: center ; background:#fff; color:#252525 ; text-decoration :none ;  border : 1px solid #ccc;border-radius : 2rem}
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Order Dispatched from Microplacer</h1>
          <p>Dear Customer,</p>
          <p>We are excited to inform you that your order has been dispatched from Microplacer, your trusted PCB manufacturing company.</p>
          <p>Here are the details of your order:</p>
          <ul>
            <li>Order ID: <strong>${_oid}</strong></li>
            <li>PCB Name : <strong>${updated.pcbs.pcbName}</strong> </li>
            <li>Order Date: <strong>${date}</strong></li>
            <li>Quantity:${updated.pcbs.quantity}</li>
            <li>Shipping Partner: <strong>${deliveryPartner}</strong></li>
            <li>Tracking Number: <strong>${trackId}</strong></li>
          </ul>
          <p>You can track your shipment by clicking the button below:</p>
          <p>If you have any questions or need further assistance, please feel free to contact our customer support team.</p>
          <p>Thank you for choosing Microplacer. We hope you have a great experience!</p>
          <p>Best regards,<br>Microplacer Team</p>
        </div>
      </body>
      </html>
       `,
    });

    return res
      .status(200)
      .json({ msg: "Paid status updated successfully", order: updatedOrder });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const changeAmount = async (req, res) => {
  const { _oid, amount } = req.body;
  if (!_oid || !amount) {
    return res.status(203).json({ msg: "provide id and amount" });
  }
  const updated = await Order.changeAmount(_oid, amount);
  if (!updated) {
    return res
      .status(500)
      .json({ msg: "internal server error while updating amount" });
  }
  return res.status(200).json({
    msg: `updated succesfully ${_oid} with Amount ${amount}`,
    order: updated,
  });
};

module.exports = {
  AdminLogin,
  getOrders,
  downloadGerberFile,
  updateOrderType,
  approveAllNewOrder,
  getAllApprovedOrders,
  getClients,
  getPricingDetail,
  updateSpecsdetails,
  updateAreaDetails,
  sendPayoutLink,
  updateOrderStatus,
  updateOrderbyId,
  updatePaidStatus,
  dispatchOrder,
  changeAmount,
};
