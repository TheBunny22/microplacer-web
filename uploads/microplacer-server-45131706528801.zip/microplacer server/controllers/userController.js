
const User = require("../models/userModel");
const validator = require("validator");
const jwt = require("jsonwebtoken");
const otpGenerator = require("otp-generator");
const nodemailer = require("nodemailer");
const path = require("path");
const fs = require("fs");
const Pricing = require("../models/pricingModel");
const PCBPriceModel = require("../models/pcbPricingModel");
const Order = require("../models/orderModel");
const FileUpload = require("../models/fileModel");
const fileUpload = require("express-fileupload");
const bcrypt = require("bcrypt");
// env encryption key
const secret = process.env.SECRET;
// token genrator
const createToken = (_id) => {
  return jwt.sign({ _id }, secret, { expiresIn: "1d" });
};
//otp generator
const otpGeneratorFun = () => {
  return otpGenerator.generate(6, {
    upperCase: false,
    specialChars: false,
    digits: true,
    lowerCaseAlphabets: false,
    upperCaseAlphabets: false,
  });
};

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true, // use SSL
  auth: {
    user: "donotreply@microplacer.com",
    pass: "Deep_HD_1994",
  },
});

const generateCartId = (username) => {
  const currentDate = new Date().toISOString().replace(/[-:.]/g, "");
  const cartId = `${username}_${currentDate}`;
  return cartId;
};
//file upload handler
const uploadOrderFile = async (req, res) => {
  try {
    // Validate file upload
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).send("No files were uploaded");
    }

    const { username, id } = req.body;
    const file = req.files.file;
    const filename = `${username}_${file.name}`;
    let folderPath;

    if (!username) {
      folderPath = path.join(__dirname, "customerfiles", id);
    } else {
      folderPath = path.join(__dirname, "customerfiles", username);
    }

    // Create the folder if it doesn't exist
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath);
    }

    // Move the file to the folder
    await file.mv(path.join(folderPath, filename));

    let cartId;
    let filePath;

    if (!username) {
      cartId = id;
      filePath = path.join(folderPath, filename);
    } else {
      cartId = generateCartId(username);
      filePath = folderPath + "/" + filename;
    }

    let updatedUser = await FileUpload.addFile(cartId, filePath);

    if (updatedUser) {
      return res.status(200).json({
        message: "Cart details inserted successfully",
        cartIDFile: {
          cartId,
          filePath: filePath.toString(),
        },
      });
    } else {
      return res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.error("Error while file uploading:", error);
    return res.status(500).json({ message: "Error while file uploading" });
  }
};

// registration
const registerUser = async (req, res) => {
  const { username, email, password, mobile } = req.body;

  if (!email || !password || !username) {
    return res.status(400).json({ msg: "All fields must be filled" });
  }
  if (!mobile) {
    return res.status(400).json({ msg: "Mobile is not provided" });
  }

  if (!validator.isEmail(email)) {
    return res.status(400).json({ msg: "Email must be valid" });
  }

  if (
    !validator.isStrongPassword(password, {
      minLength: 8,
      minLowercase: 1,
      minUppercase: 1,
      minNumbers: 1,
      minSymbols: 1,
    })
  ) {
    return res.status(400).json({ msg: "Password is not strong enough" });
  }

  try {
    const otp = otpGeneratorFun();
    const user = await User.signup(username, email, password, otp, mobile);

    // Send the OTP to the user's email
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: "Microplacer OTP Verification",
      html: `<!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>OTP Verification</title>
          <style>
            /* Global styles */
            body {
              font-family: Arial, sans-serif;
              margin: 0;
              padding: 0;
            }
            .container {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
              background-color: #f5f5f5;
            }
            h1 {
              color: #333;
              font-size: 24px;
              margin-bottom: 20px;
              text-align: center;
            }
            p {
              color: #555;
              font-size: 16px;
              margin-bottom: 20px;
            }
            .otp-container {
              background-color: #ffffff;
              border: 1px solid #e0e0e0;
              padding: 20px;
              text-align: center;
            }
            .otp {
              font-size: 36px;
              color: #333;
              margin-bottom: 20px;
            }
            .btn {
              display: inline-block;
              padding: 10px 20px;
              background-color: #007bff;
              color: #ffffff;
              text-decoration: none;
              font-size: 16px;
              border-radius: 4px;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
            }
            .footer p {
              color: #888;
              font-size: 14px;
              margin-bottom: 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>OTP Verification</h1>
            <p>Dear ${username},</p>
            <div class="otp-container">
              <p>Your OTP for verification is:</p>
              <div class="otp">${otp}</div>
              <p>Please enter this OTP to complete your verification process.</p>
            </div>
            <div class="footer">
              <p>If you didn't request this verification, you can safely ignore this email.</p>
            </div>
          </div>
        </body>
        </html>
        `,
    });

    return res
      .status(200)
      .json({ msg: `You Are Successfully Registered ${user.username}` });
  } catch (error) {
    console.log(error);
    return res.status(400).json({ err: error.message });
  }
};

// Login
const loginUser = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(203).json({ msg: "All fields must be filled" });
  }

  try {
    const user = await User.login(email, password);
    const token = createToken(user._id);

    return res
      .status(200)
      .json({ msg: `Welcome ${user.username}`, token, user });
  } catch (error) {
    return res.status(400).json({ err: error.message });
  }
};

// verify via email otp

const verifyOtp = async (req, res) => {
  // const { _id } = req.user;
  const { otp, email } = req.body;
  console.log(otp, email);
  try {
    const user = await User.verifyOtp(email, otp);
    console.log(user);

    const token = createToken(user._id);
    return res.status(200).json({ msg: user, token });
  } catch (error) {
    return res.status(400).json({ msg: error.message });
  }
};
// otp mail sending controler
const sendMailOtp = async (req, res) => {
  try {
    const { _id } = req.user;

    const otp = otpGeneratorFun();
    const user = await User.insertOTP(_id, otp);
    if (!user) {
      return res.status(203).json({ msg: `cannot update otp` });
    }
    const { email, username } = req.user;
    // Send the OTP to the user's email
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: "Microplacer OTP Verification",
      html: `<!DOCTYPE html>
      <html lang="en">
      <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>OTP Verification</title>
      <style>
      /* Global styles */
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f5f5f5;
      }
      h1 {
        color: #333;
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
      }
      p {
        color: #555;
        font-size: 16px;
        margin-bottom: 20px;
      }
      .otp-container {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        padding: 20px;
        text-align: center;
      }
      .otp {
        font-size: 36px;
        color: #333;
        margin-bottom: 20px;
      }
      .btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #007bff;
        color: #ffffff;
        text-decoration: none;
        font-size: 16px;
        border-radius: 4px;
      }
      .footer {
        text-align: center;
        margin-top: 20px;
      }
      .footer p {
        color: #888;
        font-size: 14px;
        margin-bottom: 0;
      }
      </style>
      </head>
      <body>
      <div class="container">
      <h1>OTP Verification</h1>
      <p>Dear ${username},</p>
      <div class="otp-container">
      <p>Your OTP for verification is:</p>
      <div class="otp">${otp}</div>
      <p>Please enter this OTP to complete your verification process.</p>
      </div>
      <div class="footer">
      <p>If you didn't request this verification, you can safely ignore this email.</p>
      </div>
      </div>
      </body>
      </html>
      `,
    });
    return res.status(200).json({ msg: `otp sended ` });
  } catch (error) {
    return res.status(400).json({ err: error.message });
  }
};
// resend otp handler
const resendOtp = async (req, res) => {
  try {
    const { email } = req.body;
    console.log(email);
    const user = await User.findOne({ email });
    const { _id, username } = user;
    const otp = otpGeneratorFun();
    const user1 = await User.insertOTP(_id, otp);
    if (!user1) {
      return res.status(401).json({ msg: `cannot update otp` });
    }

    // Send the OTP to the user's email
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: "Microplacer OTP Verification",
      html: `<!DOCTYPE html>
      <html lang="en">
      <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>OTP Verification</title>
      <style>
      /* Global styles */
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f5f5f5;
      }
      h1 {
        color: #333;
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
      }
      p {
        color: #555;
        font-size: 16px;
        margin-bottom: 20px;
      }
      .otp-container {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        padding: 20px;
        text-align: center;
      }
      .otp {
        font-size: 36px;
        color: #333;
        margin-bottom: 20px;
      }
      .btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #007bff;
        color: #ffffff;
        text-decoration: none;
        font-size: 16px;
        border-radius: 4px;
      }
      .footer {
        text-align: center;
        margin-top: 20px;
      }
      .footer p {
        color: #888;
        font-size: 14px;
        margin-bottom: 0;
      }
      </style>
      </head>
      <body>
      <div class="container">
      <h1>OTP Verification</h1>
      <p>Dear ${username},</p>
      <div class="otp-container">
      <p>Your OTP for verification is:</p>
      <div class="otp">${otp}</div>
      <p>Please enter this OTP to complete your verification process.</p>
      </div>
      <div class="footer">
      <p>If you didn't request this verification, you can safely ignore this email.</p>
      </div>
      </div>
      </body>
      </html>
      `,
    });
    return res.status(200).json({ msg: `otp sended ` });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ msg: `Internal server Error while sending otp` });
  }
};
// changing password controller
const changePassword = async (req, res) => {
  const { _id } = req.user;
  const { otp, newPass, email } = req.body;
  console.log(otp);
  try {
    const verifyOtp = await User.verifyOtp(email, otp);
    if (!verifyOtp) {
      return res
        .status(400)
        .json({ err: `something happened when changing passs` });
    }
    const updatedUser = await User.changePassword(_id, newPass);
    if (!updatedUser) {
      return res
        .status(400)
        .json({ err: `something happened when changing passs` });
    }
    return res.status(200).json(`changed`);
  } catch (error) {
    return res.status(400).json({ err: error.message });
  }
};

const getCart = async (req, res) => {
  const { _id } = req.user;
  if (!_id) {
    return res.status(203).json({ msg: `unauthorised user` });
  }
  const cart = await User.getCartItems(_id);
  if (!cart) {
    return res.status(200).json({ msg: `cart not available` });
  }
  res.status(200).json({ cart });
};
const addCartItem = async (req, res) => {
  const { _id } = req.user;
  const { fileid, carts } = req.body;

  const { price, ...cartitems } = carts;
  const withGst = (parseFloat(price) * 1.18);
  const newcart = { price: withGst, ...cartitems };
  console.log(withGst);
  const file = await FileUpload.findOne({ fileid: fileid });
  console.log(file);

  if (!_id) {
    return res.status(203).json({ msg: `unauthorised user` });
  }
  const cart = await User.addCartItem(_id, newcart);
  if (!cart) {
    return res.status(200).json({ msg: `cart not available` });
  }
  res.status(200).json({ cart });
};
const removeCartItem = async (req, res) => {
  const { cartItemId } = req.params;
  if (!cartItemId) {
    return res.status(203).json({ msg: `provide cart item id` });
  }
  const { _id } = req.user;
  if (!_id) {
    return res.status(203).json({ msg: `unauthorised user` });
  }
  const cart = await User.removeCartItem(_id, cartItemId);
  if (!cart) {
    return res.status(200).json({ msg: `cart not available` });
  }
  res.status(200).json({ cart });
};

const emptyCart = async (req, res) => {
  const { _id } = req.user;
  if (!_id) {
    return res.status(203).json({ msg: `unauthorised user` });
  }
  const cart = await User.emptyCart(_id);
  if (!cart) {
    return res.status(200).json({ msg: `cart not available` });
  }
  res.status(200).json({ cart });
};

const addcart = async (req, res) => {
  console.log("insert request --------------------------------------");
  try {
    const { username, cartId, cart } = req.body;

    const updatedCart = { _id: cartId, ...cart };

    const result = await User.findOneAndUpdate(
      { username, "cart._id": cartId },
      { $set: { "cart.$": updatedCart } },
      { returnOriginal: false }
    );

    let totalprice = 0;
    if (result.cart && Array.isArray(result.cart)) {
      totalprice = result.cart.reduce((sum, data) => {
        const price =
          typeof data.price === "string" ? parseFloat(data.price) : data.price;
        return parseFloat((sum + price).toFixed(2));
      }, 0);
    }

    if (result) {
      const { cart } = result;

      return res.status(200).json({
        message: "Cart details inserted successfully",
        cart,
        totalprice,
      });
    } else {
      return res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.error("Error during cart details insertion:", error);
    return res
      .status(500)
      .json({ message: "An error occurred during cart details insertion" });
  }
};

const updateCartItemById = async (req, res) => {
  const { _id } = req.user;
  const { cartItemId } = req.body;
  if (!_id) {
    return res.status(203).json({ msg: `unauthorised user` });
  }
  const cart = await User.updateCartItemById(_id, cartItemId);
  if (!cart) {
    return res.status(200).json({ msg: `cart not available` });
  }
  res.status(200).json({ cart });
};
// fecthing pricing
const fetchPrice = async (req, res) => {
  const { items, scm } = req.body;
  console.log(req.body);
  console.log(items);
  if (!items || !scm) {
    return res
      .status(400)
      .json({ msg: "Provide items and scm in the request body" });
  }

  try {
    const scqm = await Pricing.findNearestGreaterSCM(scm);

    const pricePromises = items.map(async (data) => {
      const result = await PCBPriceModel.findPercentage(
        data.specType,
        data.optionName
      );
      return result.percentage;
    });

    const percentages = await Promise.all(pricePromises);
    const totalPercentage = percentages.reduce(
      (sum, percentage) => sum + percentage,
      0
    );
    let finalPrice;
    let price1;
    if (!scqm.price) {
      price1 = scqm.pscm * scm;
      finalPrice = (parseFloat(price1) * parseFloat(totalPercentage)) / 100;
      price1 = price1 + finalPrice;
    } else {
      finalPrice = (parseFloat(scqm.price) * parseFloat(totalPercentage)) / 100;
      price1 = scqm.price + finalPrice;
       return res.status(200).json({
        incremented: finalPrice,
        perOfIncrement: totalPercentage,
        rawPrice: price1 - finalPrice,
        finalPrice: price1 - finalPrice,
        low:"true",
      });
    }
    price1 = parseInt(price1.toFixed(2));
    console.log(scqm, percentages, totalPercentage, finalPrice);

    return res.status(200).json({
      incremented: finalPrice,
      perOfIncrement: totalPercentage,
      rawPrice: price1 - finalPrice,
      finalPrice: price1,
        low:"false",
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

const selectCartItem = async (req, res) => {
  const { _id } = req.user;
  const { cartItemId, select } = req.body;
  if (!_id || !cartItemId) {
    return res.status(203).json({ msg: "Provide customer id / cart item id" });
  }
  try {
    if (select) {
      const { cart, totalPrice } = await User.selectCartItem(_id, cartItemId);
      return res.status(200).json({ msg: "slected cart ", cart, totalPrice });
    } else {
      const { cart, totalPrice } = await User.unselectCartItem(_id, cartItemId);
      return res.status(200).json({ msg: "slected cart ", cart, totalPrice });
    }
  } catch (err) {
    return res.status(500).json({ err: err.message });
  }
};

const selectAllCartItems = async (req, res) => {
  const { _id } = req.user;
  const { check } = req.body;
  if (!_id) {
    return res.status(203).json({ msg: "Provide customer id " });
  }
  try {
    if (check) {
      const { cart, totalPrice } = await User.selectAllCartItems(_id, check);
      return res.status(200).json({ msg: "slected cart ", cart, totalPrice });
    } else {
      const { cart, totalPrice } = await User.selectAllCartItems(_id, check);
      return res.status(200).json({ msg: "slected cart ", cart, totalPrice });
    }
  } catch (err) {
    return res.status(500).json({ err: err.message });
  }
};

const placeOrder = async (req, res) => {
  const { shipmentAddress } = req.body;
  const { cart, _id, email } = req.user;

  if (!shipmentAddress) {
    return res.status(400).json({ error: "Please provide full details" });
  }

  const {
    customerMobile,
    customerName,
    billingAddress,
    shippingAddress,
    taxID,
  } = shipmentAddress;

  const selectedItems = cart.filter((item) => item.selected);
  if (selectedItems < 1) {
    return res.status(203).json({ msg: "select items in cart" });
  }
  const ids = await generateOrderIds(selectedItems.length);
  try {
    selectedItems.map(async (data, index) => {
      const orderData = {
        companyName: customerName,
        amount: data.price,
        customerId: _id,
        _oid: ids[index],
        orderType: "new",
        taxid: taxID,
        billingAddress: {
          companyName: customerName,
          mobile: customerMobile,
          address: billingAddress,
        },
        shipmentAddress: {
          companyName: customerName,
          mobile: customerMobile,
          address: shippingAddress,
        },
        pcbs: data,
      };

      const order = await Order.insertOrder(orderData);
      console.log(order);
      if (!order) {
        throw new Error("Internal server error while inserting order");
      }

      await User.removeCartItem(_id, data._id);
      await transporter.sendMail({
        from: "donotreply@microplacer.com",
        to: email,
        subject: "Order Placed Microplacer",
        html: `<!DOCTYPE html>
        <html>
        <head>
          <title>Order Placed - Microplacer</title>
          <style>
            /* CSS styles */
            body {
              font-family: Arial, sans-serif;
              background-color: #f4f4f4;
              margin: 0;
              padding: 0;
            }
            .container {
              max-width: 600px;
              margin: 0 auto;
              background-color: #ffffff;
              padding: 20px;
              border: 1px solid #e0e0e0;
              border-radius: 4px;
              box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
            h1 {
              color: #333333;
              font-size: 24px;
              margin: 0 0 20px 0;
            }
            h2 {
              color: #333333;
              font-size: 18px;
              margin: 0 0 10px 0;
            }
            p {
              color: #555555;
              font-size: 16px;
              margin: 0 0 10px 0;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
            }
            th {
              background-color: #f2f2f2;
              color: #333333;
              font-weight: bold;
              padding: 10px;
              text-align: left;
              border-bottom: 1px solid #e0e0e0;
            }
            td {
              padding: 10px;
              border-bottom: 1px solid #e0e0e0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Order Placed - Microplacer</h1>
            <p>Thank you for placing your order with Microplacer!</p>
            <h2>Order Details</h2>
            <p><strong>Order ID:</strong>${order._oid}</p>
            <p><strong>Company Name:</strong>${order.billingAddress.companyName}</p>
            <p><strong>Amount:</strong>₹${order.amount}</p>
            <p><strong>Quantity:</strong>${order.pcbs.quantity}</p>
            <h2>Gerber Details</h2>
            <table>
              <tr>
                <th>Specification</th>
                <th>Value</th>
              </tr>
              <tr>
                <td>Base Material</td>
                <td>${order.pcbs.baseMaterial}</td>
                </tr>
                <tr>
                <td>Layer</td>
                <td>${order.pcbs.layer}</td>
              </tr>
              <tr>
                <td>Dimension X</td>
                <td>${order.pcbs.dimensionX}</td>
              </tr>
              <tr>
                <td>Dimension Y</td>
                <td>${order.pcbs.dimensionY}</td>
              </tr>
              <tr>
                <td>Thickness</td>
                <td>${order.pcbs.thickness}</td>
              </tr>
              <tr>
                <td>Color</td>
                <td>${order.pcbs.color}</td>
              </tr>
              <tr>
                <td>Surface Finish</td>
                <td>${order.pcbs.surfaceFinish}</td>
              </tr>
              <tr>
                <td>Outer Copper Weight</td>
                <td>${order.pcbs.outerCopperWeight}</td>
              </tr>
              <tr>
                <td>Gold Finger</td>
                <td>${order.pcbs.goldFinger}</td>
              </tr>
              <tr>
                <td>Castellated Holes</td>
                <td>${order.pcbs.castellatedHoles}</td>
              </tr>
              <tr>
                <td>Kelvin Test</td>
                <td>${order.pcbs.kelvinTest}</td>
              </tr>
              <tr>
                <td>Delivery Format</td>
                <td>${order.pcbs.deliveryFormat}</td>
              </tr>
              <tr>
                <td>Price</td>
                <td>₹${order.pcbs.price}</td>
              </tr>
              <tr>
                <td>Remarks</td>
                <td>${order.pcbs.remarks}</td>
              </tr>
            </table>
            <p>For any inquiries, please contact our customer support.</p>
            <p>
            Microplacer Technologies LLP
            <br/>
            Phone: +91 8866188126 / +91 9512012125 
            <br/>
            Email: info@microplacer.com
            </p>
          </div>
        </body>
        </html>
        `,
      });
      return order;
    });

    return res.status(200).json({
      msg: `Order placed successfully  Order Id : ${ids
        .map((it) => it)
        .join(" Order Id : ")} `,
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
async function generateOrderIds(count) {
  try {
    const lastOrder = await Order.findOne({}, { _oid: 1 })
      .sort({ _oid: -1 })
      .exec();

    const lastIdNumericPart = lastOrder
      ? parseInt(lastOrder._oid.slice(6), 10)
      : 100000;

    const orderIds = Array.from({ length: count }, (_, i) => {
      const nextIdNumericPart = lastIdNumericPart + i + 1;
      return `ORDMIP${nextIdNumericPart.toString().padStart(6, "0")}`;
    });

    return orderIds;
  } catch (error) {
    throw new Error(`Internal server error: ${error}`);
  }
}

const getOrders = async (req, res) => {
  const { _id } = req.user;
  try {
    const orders = await Order.getOrdersByCustomerId(_id);
    if (!orders) {
      return res.status(404).json({ msg: `No orders found` });
    }
    return res.status(200).json({ orders });
  } catch (err) {
    return res.status(500).json({ err: err.message });
  }
};

const getusersData = async (req, res) => {
  const { _id } = req.user;
  try {
    const user = await User.find({ _id });
    return res.status(200).json({ user });
  } catch (error) {
    return res.status(500).json({
      err: `internal server error while gettting users data : ${error}`,
    });
  }
};

const insertAddresss = async (req, res) => {
  const { _id } = req.user;
  const { mobile, address } = req.body;
  console.log(mobile, address);
  if (!mobile || !address) {
    return res.status(203).json({ msg: ` Provide full details` });
  }
  try {
    const user = await User.insertAddress(_id, mobile, address);
    if (!user) {
      return res.status(500).json({ msg: `Internal server error` });
    }
    res.status(200).json({ user });
  } catch (error) {
    return res.status(500).json({
      err: `internal server error while updating users data : ${error}`,
    });
  }
};
// gerber view routes
const getFilePath = async ({ body }, res) => {
  try {
    const { id } = body;

    const host = "192.168.0.107";

    const file = await User.aggregate([
      { $match: { "cart._id": id } },
      { $unwind: "$cart" },
      { $match: { "cart._id": id } },
      { $project: { filePath: "$cart.filePath" } },
    ]);

    if (file && file.length > 0) {
      // const link = `http://${host}:3005/api/download-file/?filepath=${encodeURIComponent(
      //   file[0].filePath
      // )}`;
      const link = `https://microplacer.in/apies/api/download-file/?filepath=${encodeURIComponent(
        file[0].filePath
      )}`;
      return res.status(200).json({ filePath: link });
    }

    const filepath = await FileUpload.getFileById(id);

    if (filepath) {
      // const link = `http://${host}:3005/api/download-file/?filepath=${encodeURIComponent(
      //   filepath.filePath
      // )}`;
      const link = `https://microplacer.in/apies/api/download-file/?filepath=${encodeURIComponent(
        filepath.filePath
      )}`;
      return res.status(200).json({ filePath: link });
    }

    return res.status(404).json({ msg: "File not found" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: "Error while fetching file" });
  }
};

const downloadFile = (req, res) => {
  const filepath = req.query.filepath;
  try {
    if (!filepath) {
      return res.status(400).json({ error: "File path is required" });
    }

    const absolutePath = path.resolve(filepath);

    res.download(absolutePath, (err) => {
      if (err) {
        console.error("Error downloading file:", err);
        res.status(500).json({ error: "Internal server error" });
      }
    });
  } catch (error) {
    res
      .status(500)
      .json({ msg: `internal server error while donloading file` });
  }
};

const UploadGerberView = async (req, res) => {
  const { id, data = {} } = req.body;

  try {
    if (!data || !id) {
      return res.status(203).json({ msg: "Provide all data" });
    }

    const file = await FileUpload.findOne({ fileid: id });
    const updated = await FileUpload.addSVG(id, data);

    // if (!file) {
    //   const user = await User.updateOne(
    //     { "cart._id": id },
    //     {
    //       $set: {
    //         "cart.$.dimensionX": data.xdimension / 1000,
    //         "cart.$.dimensionY": data.ydimension / 1000,
    //       },
    //     }
    //   );
    //   console.log(user);
    //   return res.status(200).json({ user });
    // }

    console.log(updated);
    return res.status(200).json({ updated });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ msg: error.message });
  }
};

const getGerberView = async (req, res) => {
  const { id } = req.body;

  try {
    if (!id) {
      return res.status(203).json({ msg: "Provide the file ID" });
    }

    const file = await FileUpload.findOne({ fileid: id });
    console.log(file);

    if (file) {
      const { xdimension, ydimension } = file.data;
      const dimensions = {
        dimensionX: xdimension / 1000,
        dimensionY: ydimension / 1000,
      };

      const updatedDetails = {
        dimensions,
      };

      return res.status(200).json(updatedDetails);
    }

    const user = await User.findOne({ "cart._id": id });

    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    const { dimensionX, dimensionY } = user.cart.find(
      (item) => item._id === id
    );

    const dimensions = {
      dimensionX: dimensionX,
      dimensionY: dimensionY,
    };

    const updatedDetails = {
      dimensions,
    };

    return res.status(200).json(updatedDetails);
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ msg: error.message });
  }
};

const sendQueryMail = async (req, res) => {
  const { query, name, email, companyName, subject, reqDetail } = req.body;

  try {
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: "micro@microplacer.com",
      subject: `Contact - ${subject}`,
      html: `
      <!DOCTYPE html>
  <html>
    <head>
      <style>
        /* CSS styles for the email template */
        body {
          font-family: Arial, sans-serif;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f4f4f4;
        }
        .header {
          background-color: #333;
          color: #fff;
          padding: 10px;
          text-align: center;
        }
        .content {
          margin-top: 20px;
          background-color: #fff;
          padding: 20px;
        }
        .bold {
          font-weight: bold;
        }
        .details {
          margin-top: 10px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Contact Inquiry</h1>
        </div>
        <div class="content">
        <p class="bold">Need Assistance for :</p>
        <p>${query}</p>
          <p class="bold">Name:</p>
          <p>${name}</p>
          <p class="bold">Email:</p>
          <p>${email}</p>
          <p class="bold">Company Name:</p>
          <p>${companyName}</p>
          <p class="bold">Subject:</p>
          <p>${subject}</p>
          <p class="bold">Request Details:</p>
          <p>${reqDetail}</p>
        
        </div>
      </div>
    </body>
  </html>

      `,
    });
    return res.status(200).json({ msg: req.body });
  } catch (error) {
    return res
      .status(500)
      .json(`Internal server error while sending Mail Query at Contact US `);
  }
};

const StencilInquiry = async (req, res) => {
  try {
    const file = req.files.file;
    const { price, data } = req.Body;

    const mailOptions = {
      from: "donotreply@microplacer.com",
      to: "micro@microplacer.com",
      subject: `Contact, ${price}, ${data}`,
      html: `filesvi`,
      attachments: [
        {
          filename: "file.txt",
          path: file,
        },
      ],
    };

    // Assuming you have an array of file objects in the 'files' variable
    req.files.forEach((file) => {
      mailOptions.attachments.push({
        filename: file.originalname,
        path: file.path,
      });
    });

    await transporter.sendMail(mailOptions);

    return res.sendStatus(200);
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json(`An error occurred while sending the stencil inquiry.`);
  }
};

const resetMail = async (req, res) => {
  try {
    const { username, email } = req.body;
    const otp = otpGeneratorFun();
    console.log(`${username} -- pass change request`);
    const user = await User.updateOne(
      { email: email },
      {
        $set: {
          otp: otp,
        },
      }
    );

    if (!user) {
      return res
        .status(500)
        .json({ msg: `internal error while updating otp at pass reset` });
    }
    // Send the OTP to the user's email
    await transporter.sendMail({
      from: "donotreply@microplacer.com",
      to: email,
      subject: "Microplacer Password Reset OTP",
      html: `<!DOCTYPE html>
    <html>
    
    <head>
      <meta charset="UTF-8">
      <title>Password Reset</title>
    </head>
    
    <body>
      <div style="max-width: 600px; margin: 0 auto;">
        <h1>Password Reset</h1>
        <p>Hello,</p>
        <p>We received a request to reset your password. Please use the following One-Time Password (OTP) to proceed with the password reset:</p>
        <p style="font-size: 24px; font-weight: bold;">Your OTP: <span style="color: #007bff;">${otp}</span></p>
        <p>If you didn't request a password reset, you can ignore this email. Your password will not be changed.</p>
        <p>Thank you!</p>
        <p>The Example Team</p>
      </div>
    </body>
    
    </html>
    
      `,
    });
    return res.status(200).json({ msg: "sended otp" });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

const UpdateProfile = async (req, res) => {
  try {
    const { username, email, password, otp } = req.body;
    console.log(
      `User ${username} email ${email} password changed to := ${password}`
    );
    const user = await User.verifyOtp(email, otp);
    console.log(user);
    if (!user) {
      return res.status(500).json({ msg: `otp not mached` });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const updatedUser = await User.updateOne(
      {
        email: email,
      },
      {
        password: hashedPassword,
      }
    );

    if (!updatedUser) {
      return res.status(500).json({ msg: `Users data not updated ` });
    }

    return res.status(200).json({ msg: `updated` });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

module.exports = {
  StencilInquiry,
  resetMail,
  UpdateProfile,
  registerUser,
  loginUser,
  verifyOtp,
  changePassword,
  sendMailOtp,
  getCart,
  addCartItem,
  removeCartItem,
  emptyCart,
  updateCartItemById,
  uploadOrderFile,
  fetchPrice,
  addcart,
  placeOrder,
  selectCartItem,
  selectAllCartItems,
  getOrders,
  getusersData,
  insertAddresss,
  resendOtp,
  getFilePath,
  downloadFile,
  UploadGerberView,
  sendQueryMail,
  getGerberView,
};
