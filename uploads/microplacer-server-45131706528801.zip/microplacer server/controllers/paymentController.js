const crypto = require("crypto");
const fetch = require("node-fetch");
const Payment = require("../models/paymentModal");
const Order = require("../models/orderModel");
const { json } = require("express");
require("dotenv").config();

const saltKey = process.env.SKEY;
const saltIndex = process.env.SIND;
const endpoint = "/pg/v1/pay";
const MERCHANT_ID = process.env.MERCHANT_ID;
 // Function to calculate the X-VERIFY header value
const calculateXVerifyHeader = (
  merchantId,
  merchantTransactionId,
  saltKey,
  saltIndex
) => {
  const message =
    `/pg/v1/status/${merchantId}/${merchantTransactionId}` + saltKey;
  const hash = crypto.createHash("sha256").update(message).digest("hex");
  return hash + "###" + saltIndex;
};

// Function to make the Check Status API call
const checkPaymentStatus = async (
  merchantId,
  merchantTransactionId,
  saltKey,
  saltIndex
) => {
  const apiUrl = "https://api.phonepe.com/apis/hermes/pg/v1/status/";
  const xVerifyHeader = calculateXVerifyHeader(
    merchantId,
    merchantTransactionId,
    saltKey,
    saltIndex
  );

  const headers = {
    "Content-Type": "application/json",
    "X-VERIFY": xVerifyHeader,
    "X-MERCHANT-ID": merchantId,
  };

  const url = `${apiUrl}${merchantId}/${merchantTransactionId}`;

  try {
    const response = await fetch(url, { headers });
    const responseData = await response.json();
    const transaction = await Payment.findOneAndUpdate(
      { transactionID: merchantTransactionId },
      { status: responseData }
    );
    return responseData;
  } catch (error) {
    console.error("Error checking payment status:", error);
    throw error;
  }
};

// Function to check payment status for unpaid transactions every 30 seconds
const checkPaymentStatuses = async () => {
  try {
    const unpaidTransactions = await Payment.find({
      "status.code": { $ne: "PAYMENT_SUCCESS" }, // Filter out already paid transactions
      $or: [
        { "status.data.state": { $ne: "FAILED" } }, // Ignore transactions with state "FAILED"
        { "status.code": "PENDING" }, // Include transactions with code "PENDING"
      ],
    });
    console.log(`------ unpaid Start -------`);
    console.log(unpaidTransactions);
    console.log(`------ unpaid End -------`);
    for (const transaction of unpaidTransactions) {
      const { transactionID, oid, status } = transaction;

      try {
        const lit = await checkPaymentStatus(
          MERCHANT_ID,
          transactionID,
          saltKey,
          saltIndex
        );
        transaction.status = lit; // Update response code
        await transaction.save();
        if (transaction.status.code === "PAYMENT_SUCCESS") {
          console.log(`------ Phone Pay Response -------`);
          console.log(lit);
          console.log(`-------------`);
          const order = await Order.updatePaidStatus(oid, true);
          console.log(`------ order Start -------`);
          console.log(order);
          console.log(`-------------`);
        }
      } catch (error) {
        console.error("Error checking payment status:", error);
      }
    }
  } catch (error) {
    console.error("Error checking payment statuses:", error);
  }
};


const encodeRequestAndComputeChecksum = (
  amount,
  muid,
  merchantTransactionId
) => {
  if (!amount || !muid || !merchantTransactionId) {
    throw Error(`provide all fields to encode`);
  }

  const requestData = {
    merchantId: process.env.MERCHANT_ID,
    merchantTransactionId: merchantTransactionId,
    merchantUserId: muid,
    amount: amount,
    redirectUrl: "https://microplacer.in",
    redirectMode: "POST",
    callbackUrl: "https://microplacer.in/pay-status",
    mobileNumber: "8866188126",
    paymentInstrument: {
      type: "PAY_PAGE",
    },
  };

  const encodedRequest = Buffer.from(JSON.stringify(requestData)).toString(
    "base64"
  );
  const saltedPayload = encodedRequest + endpoint + saltKey;
  const hashedPayload = crypto
    .createHash("sha256")
    .update(saltedPayload)
    .digest("hex");
  const checksum = hashedPayload + "###" + saltIndex;

  return {
    checksum: checksum,
    encodedRequest: encodedRequest,
  };
};

const createPayment = async (req, res) => {
  try {
    const { oid } = req.query;

    const order = await Order.findOne({ _oid: oid });
    if (!order) {
      return res.status(400).json({ msg: "Order not found" });
    }

    const payment = {
      oid: oid,
      amount: order.pcbs.price * 100,
      customerName: order.billingAddress.companyName,
      mobile: order.billingAddress.mobile,
    };

    const newPayment = await Payment.createPayment(payment);
    if (!newPayment) {
      return res.status(500).json({ msg: "Payment data not generated" });
    }

    const result = encodeRequestAndComputeChecksum(
      newPayment.amount,
      newPayment.muid,
      newPayment.transactionID
    );

    const fetchUrl = "https://api.phonepe.com/apis/hermes/pg/v1/pay";
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-verify": result.checksum,
      },
      body: JSON.stringify({
        request: result.encodedRequest,
      }),
    };

    const response = await fetch(fetchUrl, options);
    const data = await response.json();

    if (response.ok) {
      return res.status(200).json({
        redirect: data,
      });
    }

    return res.status(200).json({
      redirect: data,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ err: error.message });
  }
};

const getStatusController = (req, res) => {
  const { transactionID } = req.params;
  console.log("transactionID:", transactionID);

  try {
    const status = Payment.getTransactionStatus(transactionID);
    return res.status(200).json({ status: status });
  } catch (error) {
    return res.status(500).json({ err: error.message });
  }
};

module.exports = {
  createPayment,
  getStatusController,
  checkPaymentStatuses,
};
