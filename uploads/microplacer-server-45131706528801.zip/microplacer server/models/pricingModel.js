const mongoose = require("mongoose");

const pricingSchema = new mongoose.Schema({
  SCM: {
    type: Number,
    required: true,
  },
  pscm: {
    type: Number,
    required: true,
  },
  lowlimit: {
    type: Boolean,
    default: false,
  },
  upperlimit: {
    type: Boolean,
    default: false,
  },
  value: {
    type: Number,
    default: null,
  },
});

// Add the static method to find the nearest greater SCM value
pricingSchema.statics.findNearestGreaterSCM = async function (scmValue) {
  const pricingData = await this.find({ SCM: { $gte: scmValue } })
    .sort("SCM")
    .limit(1);

  const upperlimit = await this.findOne({ upperlimit: true });
  const lowerlimit = await this.findOne({ lowlimit: true });

  if (scmValue > upperlimit.SCM) {
    const price = scmValue * upperlimit.value;
    return { price };
  } else if (scmValue < lowerlimit.SCM) {
    const price = lowerlimit.value;
    return { price };
  }

  if (pricingData.length > 0) {
    return { pscm: pricingData[0].pscm };
  }
  return null;
};

pricingSchema.statics.getAll = async function () {
  const all = await this.find({});
  return all;
};

pricingSchema.statics.updateSCM = async function (val, _id, valType) {
  if ( !_id || !valType) {
    throw new Error("Please provide all parameters to update SCM");
  }

  const updateQuery = { _id };
  const updateFields = { [valType]: val };
  const updatedItem = await this.findOneAndUpdate(updateQuery, updateFields, {
    new: true,
  });

  return updatedItem;
};

const Pricing = mongoose.model("pricing", pricingSchema);

module.exports = Pricing;
