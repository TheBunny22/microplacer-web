const mongoose = require("mongoose");

const pcbPriceSchema = new mongoose.Schema({
  specType: {
    type: String,
    required: true,
  },
  option: [
    {
      optionName: {
        type: String,
        required: true,
      },
      percentage: {
        type: Number,
        required: true,
      },
    },
  ],
});

// Add index on specType field
pcbPriceSchema.index({ specType: 1 });

pcbPriceSchema.statics.getAll = async function () {
  const all = this.find({});
  return all;
};

// Add lean queries
pcbPriceSchema.statics.addOption = async function (specType, option) {
  if (!specType || !option) {
    throw Error("provide the details");
  }
  const newOption = await this.findOneAndUpdate(
    { specType },
    { $push: { option: option } },
    { new: true, lean: true }
  );
  if (!newOption) {
    throw Error("Error while adding option");
  }
  return newOption;
};

pcbPriceSchema.statics.removeOption = async function (specType, option) {
  if (!specType || !option) {
    throw Error("provide the details");
  }
  const newOption = await this.findOneAndUpdate(
    { specType },
    { $pull: { option: option } },
    { new: true, lean: true }
  );
  if (!newOption) {
    throw Error("Error while removing option");
  }
  return newOption;
};

pcbPriceSchema.statics.findPercentage = async function (specType, optionName) {
  if (!specType || !optionName) {
    throw new Error("Please provide the specType and optionName.");
  }

  const perc = await this.findOne(
    { specType, "option.optionName": optionName },
    { "option.$": 1 }
  ).lean();

  if (!perc) {
    throw new Error("Error while fetching percentage data.");
  }

  return perc.option[0];
};

pcbPriceSchema.statics.updateSpecOption = async function (
  specId,
  optionId,
  value
) {
  try {
    const pcb = await this.findById(specId);
    if (pcb) {
      const option = pcb.option.id(optionId);
      if (option) {
        option.percentage = value;
        await pcb.save();
        return pcb;
      }
    }
    return null;
  } catch (error) {
    throw error;
  }
};

const PCBPriceModel = mongoose.model("PCBPrice", pcbPriceSchema);

module.exports = PCBPriceModel;
