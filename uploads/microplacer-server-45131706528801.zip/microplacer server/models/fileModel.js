const { json } = require("express");
const mongoose = require("mongoose");

const fileSchema = new mongoose.Schema({
  fileid: {
    type: String,
    required: true,
  },
  filePath: {
    type: String,
    required: true,
  },
  data: {
    type: Object,
    default: null,
  },
});

fileSchema.statics.addFile = async function (id, filePath) {
  try {
    const file = await this.create({ fileid: id, filePath });
    return file.toObject();
  } catch (error) {
    throw new Error("Failed to add file: " + error.message);
  }
};

fileSchema.statics.getFileById = async function (id) {
  try {
    const file = await this.findOne({ fileid: id });
    if (!file) {
      throw new Error("File not found");
    }
    return file.toObject();
  } catch (error) {
    throw new Error("Failed to get file by ID: " + error.message);
  }
};

fileSchema.statics.addSVG = async function (id, svg) {
  try {
    if (!svg || !id) {
      throw Error("id or svg not provided");
    }
        const updated = await this.updateOne(
      { fileid: id },
      { $set: { data: svg } }
    );
    if (!updated) {
      throw Error("Not updated");
    }

    return updated;
  } catch (e) {
    console.log(e.message);
    throw Error("Failed to insert SVG: " + e.message);
  }
};

const FileUpload = mongoose.model("files", fileSchema);

module.exports = FileUpload;
