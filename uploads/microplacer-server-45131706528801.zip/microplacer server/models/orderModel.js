const mongoose = require("mongoose");
const User = require("./userModel");

const pcbsSchema = new mongoose.Schema({
  _id: {
    type: String,
    required: true,
  },
  pcbName: {
    type: String,
    required: true,
  },
  filePath: {
    type: String,
    required: true,
  },
  selected: {
    type: Boolean,
    default: false,
  },
  edge: {
    type: Boolean,
    default: false,
  },
  quantityLabel: {
    type: String,
    required: true,
  },
  quantityByPanel: {
    type: String,
    required: true,
  },
  panelCol: {
    type: Number,
    required: true,
  },
  panelRow: {
    type: Number,
    required: true,
  },
  panelDimensionX: {
    type: Number,
    default: null,
  },
  panelDimensionY: {
    type: Number,
    default: null,
  },
  edgeSize: {
    type: Number,
    default: 0,
  },
  baseMaterial: {
    type: String,
    required: true,
  },
  layer: {
    type: Number,
    required: true,
  },
  dimensionX: {
    type: Number,
    required: true,
  },
  dimensionY: {
    type: Number,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
  },
  thickness: {
    type: Number,
    required: true,
  },
  color: {
    type: String,
    required: true,
  },
  surfaceFinish: {
    type: String,
    required: true,
  },
  outerCopperWeight: {
    type: String,
    required: true,
  },
  goldFinger: {
    type: String,
    required: true,
  },
  castellatedHoles: {
    type: String,
    required: true,
  },
  kelvinTest: {
    type: String,
    required: true,
  },
  deliveryFormat: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  remarks: {
    type: String,
    default: null,
  },
  status: {
    type: String,
    default: "under Review",
  },
});

const orderSchema = new mongoose.Schema(
  {
    _oid: {
      type: String,
      required: true,
    },
    companyName: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    customerId: {
      type: String,
      required: true,
    },
    orderType: {
      type: String,
      default: "new",
    },
    taxid: {
      type: String,
      default: "",
    },
    paid: {
      type: Boolean,
      default: false,
    },
    deliveryPartner: {
      type: String,
      default: "",
    },
    trackId: {
      type: String,
      default: "",
    },
    paylink: {
      type: String,
      default: "",
    },
    billingAddress: {
      type: Object,
      require: true,
    },
    shipmentAddress: {
      type: Object,
      require: true,
    },
    pcbs: pcbsSchema,
    deliveryDate: {
      type:String,
      default : "",
    },
  },
  { timestamps: true }
);

orderSchema.statics.insertOrder = async function (order) {
  if (!order) {
    throw new Error("Order must be provided.");
  }
  const newOrder = await this.create(order);
  if (!newOrder) {
    throw new Error("Error while placing the order.");
  }
  return newOrder;
};

orderSchema.statics.deleteOrderById = async function (orderId) {
  if (!orderId) {
    throw new Error("Order ID must be provided.");
  }
  const deletedOrder = await this.findByIdAndDelete(orderId);
  if (!deletedOrder) {
    throw new Error("Error while deleting the order.");
  }
  return deletedOrder;
};

orderSchema.statics.getOrdersByCustomerId = async function (customerId) {
  if (!customerId) {
    throw new Error("Customer ID must be provided.");
  }
  const orders = await this.find({ customerId }).lean();
  return orders;
};
// get all new orders
orderSchema.statics.getAllOrders = async function (type) {
  const orders = await this.find({ orderType: type }).sort({ _oid: -1 }).lean();
  return orders;
};

// // get all approved orders
// orderSchema.statics.getAllApprovedOrders = async function () {
//   const orders = await this.find({ orderType: "approved" }).lean();
//   return orders;
// };
// // get all proccessed orders
// orderSchema.statics.getProccessedOrders = async function () {
//   const orders = await this.find({ orderType: "proccessed" }).lean();
//   return orders;
// };
// // get all rejected orders
// orderSchema.statics.getRejectedOrders = async function () {
//   const orders = await this.find({ orderType: "rejected" }).lean();
//   return orders;
// };

orderSchema.statics.updateOrderById = async function (orderId, updatedOrder) {
  if (!orderId || !updatedOrder) {
    throw new Error("Order ID and updated order must be provided.");
  }
  const updated = await this.updateOne({ _oid: orderId }, updatedOrder, {
    new: true,
  }).lean();
  const order = await this.find({ _oid: orderId }).lean();
  if (!updated) {
    throw new Error("Error while updating the order.");
  }

  return order;
};

orderSchema.statics.updateOrderStatus = async function (orderId, status) {
  if (!orderId || !status) {
    throw new Error("Order ID and status must be provided.");
  }
  const updated = await this.updateOne(
    { _oid: orderId },
    { "pcbs.status": status },
    {
      new: true,
    }
  ).lean();
  if (!updated) {
    throw new Error("Error while updating the order.");
  }
  return updated;
};

orderSchema.statics.updateOrdertype = async function (orderId, newType) {
  if (!orderId || !newType) {
    throw new Error("Order ID and status must be provided.");
  }
  let updated;
  if (newType === "approved") {
    updated = await this.updateOne(
      { _oid: orderId },
      {
        $set: {
          orderType: newType,
          "pcbs.status": `${newType} (waiting for Payment)`,
        },
      },
      { new: true }
    );
  } else if (newType === "rejected") {
    updated = await this.updateOne(
      { _oid: orderId },
      {
        $set: {
          orderType: newType,
          "pcbs.status": `${newType}`,
        },
      },
      { new: true }
    );
  } else {
    updated = await this.updateOne(
      { _oid: orderId },
      {
        $set: {
          orderType: newType,
          "pcbs.status": newType,
        },
      },
      { new: true }
    );
  }

  if (!updated) {
    throw new Error("Error while updating the order.");
  }
  const order = await this.findOne({ _oid: orderId });

  return order;
};
orderSchema.statics.updatePaidStatus = async function (_oid, bool) {
  try {
    let order = await this.findOne({ _oid }).exec();

    if (!order) {
      throw new Error("Order not found");
    }

   const generateDeliveryDate = () => {
        const currentDate = new Date();
      const deliveryDate = new Date(currentDate.getTime() + 9 * 24 * 60 * 60 * 1000);
      const formattedDate = deliveryDate.toDateString();
    return formattedDate;
};


    order.paid = bool;
    order.deliveryDate = order.deliveryDate || generateDeliveryDate();
    order.orderType = "processed";
    order.pcbs.status = "processed";

    const updatedOrder = await order.save();
    console.log(updatedOrder);
    return updatedOrder;
  } catch (err) {
    throw new Error(`Error updating paid status: ${err.message}`);
  }
};

orderSchema.statics.insertDLP = async function (
  _oid,
  deliveryPartner,
  trackId
) {
  try {
    let order = await this.findOne({ _oid }).exec();

    if (!order) {
      throw new Error("Order not found");
    }

    order.deliveryPartner = deliveryPartner;
    order.trackId = trackId;

    if (!order.hasOwnProperty("deliveryPartner")) {
      order.deliveryPartner = deliveryPartner;
    }
    if (!order.hasOwnProperty("trackId")) {
      order.trackId = trackId;
    }

    const updatedOrder = await order.save();
    return updatedOrder;
  } catch (err) {
    throw new Error(`Error updating delivery partner status: ${err.message}`);
  }
};

orderSchema.statics.addPaymentLink = async function (_oid, paylink) {
  try {
    let order = await this.findOne({ _oid }).exec();

    if (!order) {
      throw new Error("Order not found");
    }

    order.paylink = paylink;

    if (!order.hasOwnProperty("paylink")) {
      order.paylink = paylink;
    }

    const updatedOrder = await order.save();
    return updatedOrder;
  } catch (err) {
    throw new Error(`Error updating Payment Link: ${err.message}`);
  }
};

orderSchema.statics.changeAmount = async function (_oid, amount) {
  if (!_oid || !amount) {
    throw Error(`provide id and the amount for changng the amount `);
  }
  const updated = await this.updateOne(
    { _oid: _oid },
    { $set: { amount: amount } }
  ).lean();
  if (!updated) {
    throw Error("smoething went wrong while updating thye amount");
  }
  return updated;
};

const Order = mongoose.model("Order", orderSchema);

module.exports = Order;
