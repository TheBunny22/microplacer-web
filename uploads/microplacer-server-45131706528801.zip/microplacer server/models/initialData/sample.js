// Create sample data
const sampleData = [
  {
    companyName: "Company A",
    pcbName: "PCB 1",
    assemblyType: "Type A",
    amount: 10,
    customerId: "customer1",
    billingAddress: {
      companyName: "Company A",
      street: "123 Main St",
      city: "City A",
      pincode: 12345,
      state: "State A",
      country: "Country A",
      mobile: 1234567890,
    },
    shipmentAddress: {
      companyName: "Company A",
      street: "456 Elm St",
      city: "City B",
      pincode: 54321,
      state: "State B",
      country: "Country B",
      mobile: 9876543210,
    },
    pcbs: [
      {
        baseMaterial: "FR",
        layer: 1,
        dimensionX: 20,
        dimensionY: 20,
        quantity: 5,
        thickness: 0.8,
        color: "Green",
        surfaceFinish: "LEAD",
        outerCopperWeight: "1 oz",
        goldFinger: "YES",
        castellatedHoles: "YES",
        kelvinTest: "YES",
        deliveryFormat: "Single",
        price: 4.27,
        status: "Under Review",
      },
    ],
  },
  {
    companyName: "Company B",
    pcbName: "PCB 2",
    assemblyType: "Type B",
    amount: 5,
    customerId: "customer2",
    billingAddress: {
      companyName: "Company B",
      street: "789 Oak St",
      city: "City C",
      pincode: 67890,
      state: "State C",
      country: "Country C",
      mobile: 1357924680,
    },
    shipmentAddress: {
      companyName: "Company B",
      street: "987 Pine St",
      city: "City D",
      pincode: 98760,
      state: "State D",
      country: "Country D",
      mobile: 2468135790,
    },
    pcbs: [
      {
        baseMaterial: "FR",
        layer: 2,
        dimensionX: 30,
        dimensionY: 30,
        quantity: 10,
        thickness: 1.0,
        color: "Blue",
        surfaceFinish: "HASL",
        outerCopperWeight: "2 oz",
        goldFinger: "NO",
        castellatedHoles: "NO",
        kelvinTest: "NO",
        deliveryFormat: "Panel",
        price: 7.5,
        status: "Under Review",
      },
    ],
  },
  // Add more sample data entries here
];

const initialDataPCB = [
  {
    specType: "baseMaterial",
    option: [
      {
        optionName: "FR",
        percentage: 3,
      },
      {
        optionName: "ALU",
        percentage: 2,
      },
    ],
  },
  {
    specType: "layer",
    option: [
      {
        optionName: "1",
        percentage: 1,
      },
      { 
        optionName: "2",
        percentage: 2,
      },
      {
        optionName: "4",
        percentage: 3,
      },
    ],
  },
  {
    specType: "thickness",
    option: [
      {
        optionName: "1",
        percentage: 1,
      },
      {
        optionName: "1.6",
        percentage: 2,
      },
      {
        optionName: "2",
        percentage: 3,
      },
    ],
  },
  {
    specType: "surfaceFinish",
    option: [
      {
        optionName: "LEAD",
        percentage: 1,
      },
      {
        optionName: "HASLLFREE",
        percentage: 2,
      },
      {
        optionName: "ENIG",
        percentage: 3,
      },
    ],
  },
  {
    specType: "outerCopperWeight",
    option: [
      {
        optionName: "1 oz",
        percentage: 1,
      },
      {
        optionName: "2 oz",
        percentage: 2,
      },
    ],
  },
  {
    specType: "goldFinger",
    option: [
      {
        optionName: "YES",
        percentage: 1,
      },
      {
        optionName: "NO",
        percentage: 0,
      },
    ],
  },
  {
    specType: "castellatedHoles",
    option: [
      {
        optionName: "YES",
        percentage: 3,
      },
      {
        optionName: "NO",
        percentage: 0,
      },
    ],
  },
  {
    specType: "kelvinTest",
    option: [
      {
        optionName: "YES",
        percentage: 3,
      },
      {
        optionName: "NO",
        percentage: 0,
      },
    ],
  },
];

module.exports = { sampleData, initialDataPCB };
