const AdminLoginCreden = {
  email: "info@microplacer.com",
  password: "Deep_HD_8889",
  verified: true,
};

module.exports = AdminLoginCreden;
