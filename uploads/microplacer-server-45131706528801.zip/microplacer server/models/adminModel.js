const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

const adminSchema = new mongoose.Schema({
  email: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
  },
  otp: {
    type: Number,
    default: null,
  },
  verified: {
    type: Boolean,
    default: false,
  },
});

adminSchema.statics.createAdmin = async function (data) {
  const { email, password } = data;
  const user = await this.findOne({ $or: [{ email }] });

  if (user) {
    throw Error("User already exists");
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);


  return this.create({
    email: email,
    password: hashedPassword,
    verified: true,
  });
};

// admin login data fetch
adminSchema.statics.login = async function (email, password) {
  if (!email || !password) {
    throw Error("All fields must be filled");
  }

  const user = await this.findOne({ email });

  if (!user) {
    throw Error("Incorrect email or password");
  }

  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    throw Error("Incorrect password");
  }

  return user;
};

// verify otp via email
adminSchema.statics.verifyOtp = async function (email, otp) {
  if (!email || !otp) {
    throw new Error("Email and OTP are required fields");
  }

  const user = await this.findOne({ email }).select("otp");
  if (!user) {
    throw new Error("User not found");
  }

  if (user.otp !== otp) {
    throw new Error("OTP does not match");
  }

  const updatedUser = await this.findOneAndUpdate(
    { email },
    { $set: { otp: null, verified: true } },
    { new: true }
  );

  if (!updatedUser) {
    throw new Error("Failed to update OTP");
  }

  return updatedUser;
};

//insert otp for verification
adminSchema.statics.insertOTP = async function (_id, otp) {
  if (!_id || !otp) {
    throw Error("all field reque");
  }
  const nuser = await this.updateOne({ _id }, { $set: { otp: otp } });
  if (!nuser) {
    throw Error(`otp not updated`);
  }
  return nuser;
};

// user password change
adminSchema.statics.changePassword = async function (_id, newPass) {
  if (!_id || !newPass) {
    throw Error("id is not provided");
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(newPass, salt);
  const user = await this.updateOne(
    { _id },
    { $set: { password: hashedPassword } }
  );
  if (!user) {
    throw Error("No Data found");
  }
  return user;
};

const Admin = mongoose.model("admin", adminSchema);

module.exports = Admin;
