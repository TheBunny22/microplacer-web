const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const path = require("path");

const addressSchema = new mongoose.Schema({
  street: {
    type: String,
    default: null,
  },
  city: {
    type: String,
    default: null,
  },
  state: {
    type: String,
    default: null,
  },
  country: {
    type: String,
    default: null,
  },
});

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    mobile: {
      type: Number,
      required: true,
    },
    otp: {
      type: Number,
      default: null,
    },
    verified: {
      type: Boolean,
      default: false,
    },
    cart: {
      type: Array,
      default: [],
    },
    totalprice: {
      type: Number,
      default: null,
    },
    address: addressSchema,
  },
  {
    timestamps: true, // Add timestamps option
  }
);

// user signup data entry
userSchema.statics.signup = async function (
  username,
  email,
  password,
  otp,
  mobile
) {
  const user = await this.findOne({ $or: [{ username }, { email }] });

  if (user) {
    throw Error("User already exists");
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  return this.create({
    username,
    email,
    password: hashedPassword,
    mobile: mobile,
    otp,
  });
};

// user login check
userSchema.statics.login = async function (email, password) {
  if (!email || !password) {
    throw Error("All fields must be filled");
  }

  const user = await this.findOne({ email });
  if (!user) {
    throw Error("Incorrect email or password");
  }

  const match = await bcrypt.compare(password, user.password);

  if (!match) {
    throw Error("Incorrect  password");
  }

  if (!user.verified) {
    throw Error("verify Via email");
  }

  return user;
};

userSchema.statics.verifyOtp = async function (email, enteredOtp) {
  if (!email || !enteredOtp) {
    throw new Error("Email and OTP are required fields");
  }

  const { otp } = await this.findOne({ email });


  console.log(otp);

  const enteredOtpParsed = parseInt(enteredOtp);

  if (otp !== enteredOtpParsed) {
    throw new Error("OTP does not match");
  }

  const updatedUser = await this.findOneAndUpdate(
    { email },
    { $set: { otp: null, verified: true } },
    { new: true }
  );

  if (!updatedUser) {
    throw new Error("Failed to update OTP");
  }

  return updatedUser;
};

//
userSchema.statics.insertOTP = async function (_id, otp) {
  if (!_id || !otp) {
    throw Error("all field reque");
  }
  const nuser = await this.updateOne({ _id }, { $set: { otp: otp } });
  if (!nuser) {
    throw Error(`otp not updated`);
  }
  return nuser;
};

// user password change
userSchema.statics.changePassword = async function (_id, newPass) {
  if (!_id || !newPass) {
    throw Error("id is not provided");
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(newPass, salt);
  const user = await this.updateOne(
    { _id },
    { $set: { password: hashedPassword } }
  );
  if (!user) {
    throw Error("No Data found");
  }
  return user;
};

// user cart data fetching
userSchema.statics.getCartItems = async function (_id) {
  if (!_id) {
    throw Error("id is not provided");
  }
  const user = await this.findOne({ _id });
  if (!user) {
    throw Error("No Data found");
  }
  return user.cart;
};

// user cart  item insertion
userSchema.statics.addCartItem = async function (_id, cartItem) {
  if (!_id || !cartItem) {
    throw Error("Please provide all parameters");
  }
  const generateCartId = (username) => {
    const currentDate = new Date().toISOString().replace(/[-:.]/g, "");
    const cartId = `${username}_${currentDate}`;
    return cartId;
  };
  const cartid = generateCartId(_id);
  const user = await this.findOneAndUpdate(
    { _id },
    { $push: { cart: { _id: cartid, ...cartItem } } },
    { new: true }
  );

  if (!user) {
    throw Error("No user found");
  }

  return user.cart;
};

// user cart  item deletion
userSchema.statics.removeCartItem = async function (_id, cartItemId) {
  if (!_id || !cartItemId) {
    throw Error("Please provide all parameters");
  }

  const user = await this.findByIdAndUpdate(
    { _id },
    {
      $pull: { cart: { _id: cartItemId } },
    }
  );

  if (!user) {
    throw Error("No Item Found");
  }
  const finalCart = await this.findOne({ _id });
  return finalCart.cart;
};

// user cart nulling
userSchema.statics.emptyCart = async function (_id) {
  if (!_id) {
    throw Error("provide Id to empty cart");
  }

  const user = await this.updateOne({ _id }, { cart: [] });

  if (!user) {
    throw Error("no User Found");
  }

  return user;
};

// updating cart item by its id
userSchema.statics.updateCartItemById = async function (
  _id,
  cartItemId,
  newCartItem
) {
  if (!_id || !cartItemId) {
    throw Error("Please provide User Id and Cart Id");
  }

  const user = await this.findByIdAndUpdate(
    { _id },
    { $set: { "cart.$[elem]": newCartItem } },
    { arrayFilters: [{ "elem._id": cartItemId }] }
  );

  if (!user) {
    throw Error("No user found");
  }

  return user;
};

userSchema.statics.getAllUser = async function () {
  const allUser = await this.find();
  if (!allUser) {
    throw Error("error while fetching users");
  }
  return allUser;
};

userSchema.statics.calculateTotalPrice = async function (_id) {
  try {
    const user = await this.findOne({ _id });
    if (!user) {
      throw new Error("User not found");
    }
    const totalprice = user.cart.reduce((sum, data) => sum + data.Price, 0);
    return totalprice;
  } catch (error) {
    throw error;
  }
};

userSchema.statics.updateTotalPrice = async function (_id, totalprice) {
  try {
    await this.updateOne({ username }, { $set: { totalprice } });
  } catch (error) {
    throw error;
  }
};

userSchema.statics.selectCartItem = async function (_id, cartItemId) {
  if (!_id || !cartItemId) {
    throw Error("provide customer id and cart item Id");
  }
  const user = await this.findOneAndUpdate(
    { _id, "cart._id": cartItemId },
    { $set: { "cart.$.selected": true } },
    { new: true }
  );
  if (!user) {
    throw Error(" user  not found");
  }
  const totalPrice = user.cart.reduce((accumulator, data) => {
    const price = parseFloat(data.price);
    if (data.selected) {
      return accumulator + price;
    }
    return accumulator;
  }, 0);

  await this.findByIdAndUpdate({ _id }, { $set: { totalprice: totalPrice } });
  return { cart: user.cart, totalPrice: totalPrice };
};

userSchema.statics.unselectCartItem = async function (_id, cartItemId) {
  if (!_id || !cartItemId) {
    throw Error("provide customer id and cart item Id");
  }
  const user = await this.findOneAndUpdate(
    { _id, "cart._id": cartItemId },
    { $set: { "cart.$.selected": false } },
    { new: true }
  );
  if (!user) {
    throw Error(" user  not found");
  }
  const totalPrice = user.cart.reduce((accumulator, data) => {
    const price = parseFloat(data.price);
    if (data.selected) {
      return accumulator + price;
    }
    return accumulator;
  }, 0);

  await this.findByIdAndUpdate({ _id }, { $set: { totalprice: totalPrice } });
  return { cart: user.cart, totalPrice };
};

userSchema.statics.selectAllCartItems = async function (_id, selectAll) {
  if (!_id) {
    throw Error("Please provide customer ID");
  }

  const user = await this.findOneAndUpdate(
    { _id },
    { $set: { "cart.$[].selected": selectAll } },
    { new: true }
  );

  if (!user) {
    throw Error("User not found");
  }

  const totalPrice = user.cart.reduce((accumulator, data) => {
    const price = parseFloat(data.price);
    if (data.selected) {
      return accumulator + price;
    }
    return accumulator;
  }, 0);
  await this.findByIdAndUpdate({ _id }, { $set: { totalprice: totalPrice } });
  return { cart: user.cart, totalPrice };
};

userSchema.statics.insertAddress = async function (_id, mobile, address) {
  if (!_id) {
    throw Error("Please provide customer ID");
  }

  const user = await this.findOneAndUpdate(
    { _id },
    { $set: { mobile: mobile, address: address } },
    { new: true }
  );

  if (!user) {
    throw Error("User not found");
  }
  return user;
};

const User = mongoose.model("Userdata", userSchema);

module.exports = User;
