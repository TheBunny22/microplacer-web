const mongoose = require("mongoose");
const crypto = require("crypto");
const fetch = require("node-fetch");
const Order = require("./orderModel");
require("dotenv").config();

const transactionSchema = new mongoose.Schema({
  oid: {
    type: String,
    required: true,
  },
  muid: {
    type: String,
    required: true,
  },
  transactionID: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  customerName: {
    type: String,
    required: true,
  },
  mobile: {
    type: Number,
    required: true,
  },
  status: {
    type: Object,
    default: {},
  },
});
// create payment
transactionSchema.statics.createPayment = async function (transaction) {
  if (!transaction) {
    throw new Error("Provide all fields");
  }

  const lastTransaction = await this.findOne(
    {},
    {},
    { sort: { transactionID: -1 } }
  );
  const lastMUIDNumber = lastTransaction
    ? parseInt(lastTransaction.muid.slice(4), 10)
    : 0;
  const lastTransactionNumber = lastTransaction
    ? parseInt(lastTransaction.transactionID.slice(7), 10)
    : 0;

  const newMUIDNumber = lastMUIDNumber + 1;
  const newTransactionNumber = lastTransactionNumber + 1;

  const newMUID = `MUID${newMUIDNumber.toString().padStart(4, "0")}`;
  const newTransactionID = `ORMIPAY${newTransactionNumber
    .toString()
    .padStart(4, "0")}`;

  const newTransaction = await this.create({
    ...transaction,
    muid: newMUID,
    transactionID: newTransactionID,
  });

  if (!newTransaction) {
    throw new Error("Transaction not created");
  }

  return newTransaction;
};
// to get all transactions
transactionSchema.statics.getAll = async function () {
  const transactions = await this.find();
  if (!transactions) {
    throw Error(`No transactions happened`);
  }
  return transactions;
};
// set transaction status
transactionSchema.statics.getTransactionStatus = async function (
  transactionID , status
) {
  if (!transactionID) {
    throw Error("Provide all fields in setting payment status");
  }

  const transaction = await this.findOne({ transactionID });
  if (!transaction) {
    throw new Error("Transaction not found");
  }

  return transaction.status.success;
};

// get transaction usinf transaction Id
transactionSchema.statics.getStatus = async function (id) {
  if (!id) {
    throw Error(`provide ID for finding transaction status`);
  }
  const transaction = this.findOne({ transactionID: id });
  if (!transaction) {
    throw Error(`transaction not found`);
  }
  return transaction.status.success;
};

const Payment = mongoose.model("payment", transactionSchema);

module.exports = Payment;
