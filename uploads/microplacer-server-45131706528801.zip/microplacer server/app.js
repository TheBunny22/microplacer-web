require("dotenv").config();
const express = require("express");
const { connect, close } = require("./db");
const cors = require("cors");
const https = require("https");
const fs = require("fs");
const userRoutes = require("./routes/userRoutes");
const Pricing = require("./models/pricingModel");
const initialData = require("./models/initialData/pricingDATA");
const { initialDataPCB } = require("./models/initialData/sample");
const PCBPriceModel = require("./models/pcbPricingModel");
const adminRoutes = require("./routes/adminRoutes");
const Admin = require("./models/adminModel");
const AdminLoginCreden = require("./models/initialData/adminData");
const paymentRoutes = require("./routes/paymentRoutes");
const { checkPaymentStatuses } = require("./controllers/paymentController");

const app = express();
const port = process.env.PORT;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// Configure SSL options
const sslOptions = {
  key: fs.readFileSync("./cert/key.pem"),
  cert: fs.readFileSync("./cert/cert.pem"),
};

// user Routes
app.use("/api", userRoutes);
app.use("/admin", adminRoutes);
app.use("/payment", paymentRoutes);
app.get("/",(req,res)=>{
    res.send("im an api")
});
app.post("/pay-status",(req,res)=>{
     console.log(req.headers);
     console.log(req.body);
     res.status(200).json(`ok`);
});
// Connect to the database and start the server
connect()
  .then(() => {
    async function populateInitialData() {
      try {
        const get = await Pricing.find({});
        if (get.length > 0) {
          console.log("Data is already there");
        } else {
          await Pricing.create(initialData);
          console.log("Initial data added successfully.");
          await Admin.createAdmin(AdminLoginCreden);
        }
        const data = await Pricing.findNearestGreaterSCM(100);
        console.log(data);
      } catch (error) {
        console.error("Error adding initial data:", error);
      }
    }

    async function startServer() {
      // Start the Express.js server with SSL
      const server = https.createServer(sslOptions, app);

      server.listen(port, () => {
        console.log("Server is running on port " + port);
      });
      setInterval(checkPaymentStatuses, 30000);
      await populateInitialData();
    }

    startServer().catch((error) => {
      console.error("Failed to start the server:", error);
      process.exit(1); // Exit the application if there's an error starting the server
    });
  })
  .catch((error) => {
    console.error("Failed to connect to MongoDB:", error);
    process.exit(1); // Exit the application if the database connection fails
  });

const Insert = async () => {
  const get = await PCBPriceModel.find({});

  if (get.length > 0) {
    console.log("Data is already there");
  } else {
    PCBPriceModel.create(initialDataPCB)
      .then(() => {
        console.log("Initial data inserted successfully.");
      })
      .catch((error) => {
        console.error("Error inserting initial data:", error);
      });
  }
};
Insert();

// Gracefully close the MongoDB connection when the application is terminated
process.on("SIGINT", () => {
  close()
    .then(() => {
      console.log("MongoDB connection closed. Application terminated.");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Error closing MongoDB connection:", error);
      process.exit(1);
    });
});
