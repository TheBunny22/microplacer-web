const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

const secret = process.env.SECRET;

const authenticateUser = async (req, res, next) => {
  try {
    // Get the token from the request headers
    const { authorization } = req.headers;

    if (!authorization || !authorization.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: No token provided" });
    }

    const token = authorization.split(" ")[1];

    // Verify and decode the token
    const { _id } = jwt.verify(token, secret);

    // Check if the user exists in the database
    const user = await User.findOne({ _id });

    if (!user) {
      return res.status(401).json({ error: "Unauthorized: User not found" });
    }

    // Attach the user object to the request for further use
    req.user = user;
    // Move to the next middleware or route handler
    next();
  } catch (err) {
    return res.status(401).json({ error: "Unauthorized: Invalid token" });
  }
};

module.exports = authenticateUser;
